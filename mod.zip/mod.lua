-- This is the Sample Mod!

-- I would recommend keeping your mod_id in a variable to access with create() methods and stuff
-- there's a bunch of methods that prepend your mod_id to the name/oids so it comes in handy!
MOD_NAME = "geology_mod"


-- register is called first to register your mod with the game
-- https://wiki.apico.buzz/wiki/Modding_API#register()
function register()
  -- register our mod name, hooks, and local modules
  -- you can see a full list of hooks here:
  -- https://wiki.apico.buzz/wiki/Modding_API#Hooks
  return {
    name = MOD_NAME,
    hooks = {"ready", "gui", "click"}, -- subscribe to hooks we want so they're called
    modules = {"utility"} -- load other modules we need, in this case "/modules/utility.lua"
  }
end

-- init is called once registered and gives you a chance to run any setup code
-- https://wiki.apico.buzz/wiki/Modding_API#init()
function init() 

  -- turn on devmode
  api_set_devmode(true)

  -- log to the console
  log("init", "Hello World!")

  -- defines the new bee produce
  --define_item()
  -- define a new bee species, add a hybrid recipe for it, and add a new trait to all bees
  define_bee()

  return "Success"
end


-- ready is called once all mods are ready and once the world has loaded any undefined instances from mods in the save
-- https://wiki.apico.buzz/wiki/Modding_API#ready()
function ready()

  -- we're going to get the mod "data" file to see if this is the first time the mod has loaded
  api_get_data()

  
  -- play a sound to celebrate our mod loading! :D
  api_play_sound("confetti")

end


-- data is called any time we run api_get_data() or api_set_data()
-- https://wiki.apico.buzz/wiki/Modding_API#data()
function data(ev, data)
  
  -- for data load, data is nil if we have no data.json file existing
  -- you can have one in your mod root by default, or just make one 
  -- when you call api_set_data()
  if (ev == "LOAD" and data ~= nil) then
    -- worlds dont have unique identifiers so we can check with the player name
    name = api_gp(api_get_player_instance(), "name")
    if data["players"][name] == nil then
      -- this is the first time we have loaded this mod for this player
      -- we can use this to do something, i.e. spawn an object
      api_log("data", "First time!")
      -- once done we set the data value and update the data for next time
      data["players"][name] = true
      api_set_data(data)
    else
      -- this isn't our first rodeo!!
      api_log("data", "Loaded before.")
    end
  end

  -- check save was successful
  if (ev == "SAVE" and data ~= nil) then
    -- save was successful!
  end

end

-- click is called whenever the player clicks
-- https://wiki.apico.buzz/wiki/Modding_API#click()
function click(button, click_type)
end

